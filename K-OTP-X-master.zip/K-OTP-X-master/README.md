<p align="center">
  <b> Follow on Social Media Platforms </b>
</p>
<p align="center">
<a href="https://www.instagram.com/venexyyy"><img title="GitHub version" src="https://img.shields.io/badge/-Instagram-blue" ></a> 
</p>

# ScreenShot
![Screenshot](https://user-images.githubusercontent.com/57313495/81038008-9d052f00-8e72-11ea-87b0-68c88e8e563b.png)


# INSTALLATION [ TERMUX APP --ANDROID ]
* git clone https://github.com/predator0x300/K-OTP-X
* cd K-OTP-X/
* chmod 777 start.sh
* ./start.sh
* ./An-K-OTP-X.sh

# INSTALLATION [ KALI ]
* git clone https://github.com/predator0x300/K-OTP-X
* cd K-OTP-X/
* chmod 777 setup.sh
* ./setup.sh
* ./K-OTP-X.sh

# AVAILABLE TUNNELLING OPTIONS
1. LOCALHOST
2. NGROK (https://ngrok.com/)
# TESTED ON FOLLOWING:-
* Kali Linux - 2020.1a (version)
* Parrot OS - Rolling Edition (version)
* Ubuntu 
* Arch Linux
* Termux App
# PREREQUISITES
* sudo - [ MUST ]
* php
* apache2
* ngrok Token
# LANGUAGE 
* Bash Script


# Contact For Contribute & Issues 

                                      EMAIL FOR ISSUES AND CONTRIBUTE : predator0x300@gmail.com

# DISCLAIMER
                                       TO BE USED FOR EDUCATIONAL PURPOSES ONLY

The use of the K-OTP-X is COMPLETE RESPONSIBILITY of the END-USER. Developers assume NO liability and are NOT responsible for any misuse or damage caused by this program. 


